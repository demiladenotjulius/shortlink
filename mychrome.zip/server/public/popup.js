// document.getElementById('testButton').addEventListener('click', () => {
//   const websiteUrl = 'https://shortlink-puce.vercel.app';
  
//   chrome.tabs.create({ url: websiteUrl });
// });
  